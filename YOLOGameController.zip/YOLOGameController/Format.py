#from ultralytics import YOLO
#model = YOLO(r"C:\Users\chris\Desktop\Weights_TimTest\best.pt")
#export_path = model.export(format="openvino", imgsz=736)
#print(export_path)

import openvino as ov

print(ov.Core().available_devices)