import pyautogui
import time
import pydirectinput
from Detect import detect_frames
from pathlib import Path
import subprocess
import sys

GAME_DIR = Path(__file__).resolve().parent / "Mario-Level-1-master"

def main():
    # This waits until the game exits.
    subprocess.run(
        [sys.executable, str(GAME_DIR / "mario_level_1.py")],
        cwd=GAME_DIR,
    )

    # Put the code you want to run afterward here.
    print("The game has closed; continuing with the rest of the program.")
    # do_later_code()

if __name__ == "__main__":
    main()




armed = True


for result in detect_frames():
    detected_classes = {
        result.names[int(class_id)]
        for class_id in result.boxes.cls
    }

    print("Detected:", detected_classes, flush=True)

    if "fist" in detected_classes:
        armed = True
    elif "ok" in detected_classes and armed :
        pyautogui.press("space")
        armed = False
    elif "peace" in detected_classes:
        pydirectinput.keyDown('a')
        time.sleep(.005)
        pydirectinput.keyUp('a')
        #armed = False
    elif "like" in detected_classes :
        pydirectinput.keyDown('w')
        time.sleep(.005)
        pydirectinput.keyUp('w')
        #armed = False
    elif "dislike" in detected_classes :
        pydirectinput.keyDown('s')
        time.sleep(.005)
        pydirectinput.keyUp('s')
        #armed = False
    elif "stop" in detected_classes:
        pydirectinput.keyDown('d')
        time.sleep(.005)
        pydirectinput.keyUp('d')
        #armed = False
